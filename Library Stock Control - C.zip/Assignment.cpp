//Yousef Indja - C17396636
//Bonus feature involves allowing a customer to recommed a book to the library
//if the book gets recommeded 5 times it is added to the library stock.

#define _CRT_SECURE_NO_WARNINGS
#define bool int
#define false 0
#define true (!false)
#define SIZE 10

#include <malloc.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>





struct book{
	char id[50];
	char name[50];
	char author[50];
	int pubYear;
	char custName[50];
	bool loaned;
	int loanCounter;
	bool recommended;
	int recCounter;
};

struct LinearNode {
	struct book *element;
	struct LinearNode *next;
};

bool menu(bool);
void addBooks();
bool isEmpty();
void viewAllBooks();
void deleteBook();
void takeOutBook();
void returnBook();
void mostPopBook();
void leastPopBook();
void specificBook();
void recommendABook();

//exit used to exit from menu
bool exiit;
struct LinearNode *front = NULL;
struct LinearNode *last = NULL;




int main(){
	bool answer = menu(exiit);
	if (answer == true){
		printf("Exiting System. Goodbye");
	}
}


bool menu(bool exiit){
	int response;
	exiit = false;
	do{
		printf("----------------------------------------------------------------------");
		printf("\n|| 1. Add a new book to the library                                 ||");
		printf("\n|| 2. Allow a customer to take out a book                           ||");
		printf("\n|| 3. Allow customer to return a book                               ||");
		printf("\n|| 4. Delete an old book from stock                                 ||");
		printf("\n|| 5. View all books                                                ||");
		printf("\n|| 6. View a specific book                                          ||");
		printf("\n|| 7. View details of most popular and least popular book           ||");
		printf("\n|| 8. Recommend a book for the library to add                       ||");
		printf("\n|| 9. Exit the system                                               ||");
		printf("\n----------------------------------------------------------------------");
		printf("\n\nPlease choose a number from 1 to 9:");
		scanf("%d", &response);
		printf("\n");
		
		if (response == 1){
			addBooks();
		} else if (response == 2){
			takeOutBook();
		} else if (response == 3){
			returnBook();
		} else if (response == 4){
			deleteBook();
		} else if (response == 5){
			viewAllBooks();
		} else if (response == 6){
			specificBook();
		} else if (response == 7){
			mostPopBook();
			leastPopBook();
		} else if (response == 8){
			recommendABook();
		} else if (response == 9){
			exiit = true;
		} else {
			printf("Error: Invlaid choice\n");
		}
	}while (exiit == false);
	return exiit;
}

void addBooks() {	

	struct LinearNode *aNode, *current, *previous;
	struct book *anElement;
	anElement = (struct book *)malloc(sizeof(struct book));
	int bookCounter = 0;
	bool ok, duplicate, correctFormat;
	
	
	if (anElement == NULL)
    		printf("Error: no space for the new element\n");
	else if (bookCounter !=10)
	{
	    printf("Please enter book details below\n................................\n");
	    	getchar();
	    do{
	        current = previous = front;
	        correctFormat = true;
	    	duplicate = false;
	    	ok = false;
	    	
	    	printf("ID Number: ");
		    fgets(anElement->id, 50, stdin);
		    
			for(int i = 0; i<=8; i++){
				if (isdigit(anElement->id[i]) && i!=4){	
					//do nothing	
				} else if(i == 4 && anElement->id[4] == '-'){
					//do nothing	
				} else{
					correctFormat = false;
				}
			}
		
			
			if(correctFormat == true){
				while (current != NULL && duplicate != true) {
				//Compares the strings, equals 0 if same
				int s = strcmp(anElement->id, current->element->id);
		    	if (s != 0){
					previous = current;
					current = current->next;
				}else {
					duplicate = true;
				}
			}
			if (duplicate == false){
				ok = true;
			} else {
				printf("Error: ID number must be unique. Please try again\n");
			}
			} else {
				printf("Error: ID must be in the form 'xxxx-xxxx'.\n");
			}
	     	
		}while(ok == false);

    	printf("Book Name: ");
		fgets(anElement->name, 50, stdin);
    	printf("Author's Name: ");
	   	fgets(anElement->author, 50 , stdin);
	   	printf("Year of Publication: ");
	   	scanf("%d", &anElement->pubYear);
	   	while(anElement->pubYear<2008){
		    printf("Error: Publication year cannot be older than 2008. Please try again.\n");
			printf("Year of Publication: ");
	   	    scanf("%d", &anElement->pubYear);
		}
		
		anElement->loaned = false;
		anElement->loanCounter = 0;
		anElement->recommended = false;
		printf("\nBook has been added successfully.\n");
			
		aNode = (struct LinearNode *)malloc(sizeof(struct LinearNode));

	    if (aNode == NULL)
	     	printf("Error - no space for the new node\n");
		else { 
		    bookCounter;
	       	aNode->element = anElement;
		    aNode->next = NULL;	
		}
    
		if (isEmpty())  
		{
			front = aNode;
			last = aNode;
        }else 
		{
			last->next = aNode;
			last = aNode;
		} 
    }
}

void takeOutBook(){
	struct LinearNode *current, *previous;
	bool found = false;
	char outId[50];
	int checkId;
	
	getchar();
	printf("Enter book ID that you wish to take out: ");
	fgets(outId, 50, stdin);
	
	if (isEmpty())
		printf("Error - there are no books in the library\n");
	else  {
		current = previous = front;

		while (found == false && current != NULL) {
			//Compares the strings, equals 0 if same
			checkId = strcmp(outId, current->element->id); 
			if (checkId == 0){
				if (current->element->recommended == false){
					if(current->element->loaned == false){
					found = true;
				} else{
					printf("Error - this book is currently being loaned out.\n");
					return;
				}
				}
				
			}else {
				previous = current;
				current = current->next;
			}
		} 
		if (found == true){
			printf("Input name of person taking out book:");
			fgets(current->element->custName, 50, stdin);
			// add 1 to loan counter
			int tempCounter = current->element->loanCounter;
			tempCounter++;
			current->element->loanCounter = tempCounter;
			//update the details to show that the book is loaned out
			current->element->loaned = true;
			printf("\nBook taken out successfully\n");
		} else{
			printf("\nError: This book could not be found\n");
		}		
	}
}

void returnBook(){
	struct LinearNode *current, *previous;
	char tempName[50], tempId[50];
	bool found = false;
	int checkName, checkId;
	
	getchar();
	printf("Enter book ID: ");
	fgets(tempId, 50, stdin);
	printf("Enter Name: ");
	fgets(tempName, 50, stdin);
	
	printf("\n");
	if (isEmpty())
		printf("Error: there are no books in the library\n");
	else  {
		current = previous = front;
		while (found == false && current != NULL) {
			//Compares the strings, equals 0 if same
			checkName = strcmp(tempName, current->element->custName);
			checkId = strcmp(tempId, current->element->id);
			if (checkName == 0 && checkId == 0){
					found = true;
					break;
			}else {
				previous = current;
				current = current->next;
			}
		}
		if (found == true){
			//update the details so that the book no longer shows that it is being loaned out
			current->element->loaned = false;
			printf("Book has been returned successfully.\n");
		} else {
			printf("Error - this book does not exist \n");
		}	
	}
}

void deleteBook() {
	struct LinearNode *current, *previous;
	bool found = false;
	int checkId;

	char tempId[50];
	getchar();
	printf("Enter book ID to delete: ");
	fgets(tempId, 50, stdin);
	
    printf("\n");
	if (isEmpty()){
		printf("Error - there are no books in the library\n");
	}else  {
		current = previous = front;
		while (found == false && current != NULL) {
			//Compares the strings, equals 0 if same
			checkId = strcmp(tempId, current->element->id);
			if (checkId == 0){
				if(current->element->pubYear <= 2010){
				found = true;
				} else{
					previous = current;
				    current = current->next;
				}
			}	
			else {
				previous = current;
				current = current->next;
			}
		} 
	}

	if (found == false){
		printf("Error - there is no such book with ID %s or the book is not older than 2010\n", tempId);
	}else if (current == front) { 
			front = front->next;
			free(current);
			printf("Book with id %s has been deleted\n", tempId);
		} 
		else if (current == last) {
            free(current);
            previous->next = NULL;
            last = previous;
            printf("Book with id %s has been deleted\n", tempId);
        }
		else {
			previous ->next= current->next;
			free(current);
			printf("Book with id %s has been deleted\n", tempId);
		} 
		
}

void viewAllBooks() {
	struct LinearNode *current;

    printf("\n");
    
	if (isEmpty())
		printf("Error - there are no books in the library\n");
	else {
		current = front;
		while (current != NULL) {
			if(current->element->recommended == false){
				printf("\nCurrent books in the library\n.......................\n");
				printf("Book id : %s", current->element->id);
				printf("Name: %s", current->element->name);
				printf("Author: %s", current->element->author);
				printf("Publication Year: %d \n", current->element->pubYear);
				//only show loaned out details if the book is currently being loaned out
				if(current->element->loaned == true){
					printf("Loaned out: Yes\n");
					printf("Customer currently borrowing book: %s", current->element->custName);
				} else{
		        	printf("Loaned out: No\n");
				}
				printf("Loaned amount: %d\n", current->element->loanCounter);
				printf("\n");
				current=current->next;
			} else {
				printf("\nCurrent books on the recommended list\n...........................\n");
				printf("Name: %s", current->element->name);
				printf("Author: %s", current->element->author);
				printf("Publication Year: %d \n", current->element->pubYear);
				printf("Times recommended: %d\n" ,current->element->recCounter);

				current=current->next;
			}
		}
			
    }
} 

void specificBook(){
	struct LinearNode *current, *previous;
	bool found = false;
	char tempId[50];
	
	getchar();
	printf("Enter book ID to find:");
	fgets(tempId, 50, stdin);
	
    printf("\n");
	if (isEmpty()){
		printf("Error - there are no books in the library\n");
	}else  {
		current = previous = front;
		while (found == false && current != NULL) {
			//Compares the strings, equals 0 if same
			int checkId = strcmp(tempId, current->element->id);
			if (checkId == 0){
				found = true;
				break;
			}
			else {
				previous = current;
				current = current->next;
			}
		} 
	}

	if (found == false){
		printf("Error - there is not such book with ID %s\n", tempId);
	}else {
		if(current->element->recommended == false){
			printf("The details for this book are below\n..................................................\n");
			printf("Book id : %s", current->element->id);
	  	 	 printf("Name: %s", current->element->name);
			printf("Author: %s", current->element->author);
			printf("Publication Year: %d \n", current->element->pubYear);
			//only show loaned out details if the book is currently being loaned out
			if(current->element->loaned == true){
				printf("Loaned out: Yes\n");
				printf("Customer currently borrowing book: %s", current->element->custName);
			} else{
	        	printf("Loaned out: No\n");
			}
			printf("Loaned amount: %d\n", current->element->loanCounter);
			}

	}
}



void mostPopBook(){
	struct LinearNode *current, *previous;
	bool found = false;
	int counter = 0; 
	
	if (isEmpty()){
		printf("Error - there are no books in the library\n");
	}else  {
		current = previous = front;
		while (found == false && current != NULL) {
			
			if (current->element->loanCounter >= counter){
				found = true;
				counter = current->element->loanCounter;
				
			}else {
				previous = current;
				current = current->next;
			}
		} 
	}
	
	if (found == true){
		printf("The details for the most popular book are below\n..................................................\n");
		printf("Book id : %s", current->element->id);
	    printf("Name: %s", current->element->name);
		printf("Author: %s", current->element->author);
		printf("Publication Year: %d \n", current->element->pubYear);
		if(current->element->loaned == true){
			printf("Loaned out: Yes\n");
			printf("Customer currently borrowing book: %s", current->element->custName);
		} else{
	        printf("Loaned out: No\n");
		}
		printf("Loaned amount: %d\n", current->element->loanCounter);
	} else {
		printf("No books have been found\n");
	}
}

void leastPopBook(){
	struct LinearNode *current, *previous;
	bool found = false;
	int counter = 0; 
	
	if (isEmpty()){
	}else  {
		current = previous = front;
		while (found == false && current != NULL) {
			if (current->element->loanCounter <= counter){
				found = true;
				counter = current->element->loanCounter;
			}else {
				previous = current;
				current = current->next;
			}
		} 
	}
	
	if (found == true){
		printf("The details for the least popular book are below\n..................................................\n");
		printf("Book id : %s", current->element->id);
	    printf("Name: %s", current->element->name);
		printf("Author: %s", current->element->author);
		printf("Publication Year: %d \n", current->element->pubYear);
		if(current->element->loaned == true){
			printf("Loaned out: Yes\n");
			printf("Customer currently borrowing book: %s", current->element->custName);
		} else{
	        printf("Loaned out: No\n");
		}
		printf("Loaned amount: %d\n", current->element->loanCounter);
	} else {
	}
}

void recommendABook(){
	struct LinearNode *aNode, *current, *previous;
	struct book *anElement;
	anElement = (struct book *)malloc(sizeof(struct book));
	char recBook[50];
	int checkName;
	bool found = false, correctBook = false;
	
	getchar();
	printf("Enter the name of the book you wish to recommend: ");
	fgets(recBook, 50, stdin);
	
	printf("\n");
	if (isEmpty()){
		printf("Error - there are no books in the library\n");
	}else  {
		current = previous = front;
		while (found == false && current != NULL) {
			//Compares the strings, equals 0 if same
			int checkName = strcmp(recBook, current->element->name);
			if (checkName == 0){
				found = true;
				break;
			}
			else {
				previous = current;
				current = current->next;
			}
		} 
	}
	
	if(found == false){
		if (anElement == NULL)
    		printf("Error: no space for the new element\n");
		else 
		{

		    printf("Please enter book details below\n................................\n");
    		printf("Book Name: ");
			fgets(anElement->name, 50, stdin);
	    	printf("Author's Name: ");
		   	fgets(anElement->author, 50 , stdin);
	   		printf("Year of Publication: ");
	   		scanf("%d", &anElement->pubYear);
	   		while(anElement->pubYear<2008){
			    printf("Error: Publication year cannot be older than 2008. Please try again.\n");
				printf("Year of Publication: ");
	   	    	scanf("%d", &anElement->pubYear);
			}
		
			anElement->loaned = false;
			anElement->loanCounter = 0;
			anElement->recommended = true;
			anElement->recCounter = 1;
			printf("\nBook has been added to the recommended list.\n");
			
			aNode = (struct LinearNode *)malloc(sizeof(struct LinearNode));

	    	if (aNode == NULL)
	     	printf("Error - no space for the new node\n");
			else { 

	       		aNode->element = anElement;
		   		 aNode->next = NULL;	
			}
    
			if (isEmpty())  
			{
				front = aNode;
				last = aNode;
        	}else 
			{
				last->next = aNode;
				last = aNode;
			} 	 
		}	
	} else {
		if(current->element->recommended == true){
			printf("This book has been recommended before. We have increased its number of recommendations.\n");
			int tempRecCounter = anElement->recCounter;
			tempRecCounter++;
			anElement->recCounter = tempRecCounter;
			if(anElement->recCounter>=5){
				anElement->recommended = false;
			}
		}else{
			printf("This book is already in the library\n");
		}

		}
}

bool isEmpty() {
	if (front == NULL)
		return true;
	else
		return false;
}

