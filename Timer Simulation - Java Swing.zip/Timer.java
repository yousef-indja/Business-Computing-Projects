/*Yousef Indja - C17396636 - 00SD3 CA2*/
import javax.swing.*;



import java.awt.*;
import java.awt.event.*;
import java.io.*;

import net.miginfocom.swing.MigLayout;

public class Timer extends JFrame implements ActionListener{
	
	// Interface components
	
	// Fonts to be used
	Font countdownFont = new Font("Arial", Font.BOLD, 20);
	Font elapsedFont = new Font("Arial", Font.PLAIN, 14);
	
	// Labels and text fields
	JLabel countdownLabel = new JLabel("Seconds remaining:");
	JTextField countdownField = new JTextField(15);
	JLabel elapsedLabel = new JLabel("Time running:");
	JTextField elapsedField = new JTextField(15);
	JButton startButton = new JButton("START");
	JButton pauseButton = new JButton("PAUSE");
	JButton stopButton = new JButton("STOP");
	
	// The text area and the scroll pane in which it resides
	JTextArea display;
	
	JScrollPane myPane;
	
	// These represent the menus
	JMenuItem saveData = new JMenuItem("Save data", KeyEvent.VK_S);
	JMenuItem displayData = new JMenuItem("Display data", KeyEvent.VK_D);
	
	JMenu options = new JMenu("Options");
	
	JMenuBar menuBar = new JMenuBar();
	
	// These booleans are used to indicate whether the START button has been clicked
	boolean started;
	
	// and the state of the timer (paused or running)
	boolean paused;
	
	// Number of seconds
	long totalSeconds = 0;
	long secondsToRun = 0;
	long secondsSinceStart = 0;
	
	// This is the thread that performs the countdown and can be started, paused and stopped
	TimerThread countdownThread;
	TimerThread pauseThread;

	// Extra components I used
	boolean stopped; //Used to keep track of whether the timer has been completely stopped or not
	File file;
	JFileChooser chooser = new JFileChooser();
	Thread thread;
	TimerDialog tDialog;
	// Interface constructed
	Timer() {
		countdownThread = new TimerThread(countdownField, elapsedField, 0, secondsSinceStart, Timer.this);
		chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
		setTitle("Timer Application");
		
    	MigLayout layout = new MigLayout("fillx");
    	JPanel panel = new JPanel(layout);
    	getContentPane().add(panel);
    	
    	options.add(saveData);
    	saveData.addActionListener(this);
    	options.add(displayData);
    	displayData.addActionListener(this);
    	menuBar.add(options);
    	
    	panel.add(menuBar, "spanx, north, wrap");
    	
    	MigLayout centralLayout = new MigLayout("fillx");
    	
    	JPanel centralPanel = new JPanel(centralLayout);
    	
    	GridLayout timeLayout = new GridLayout(2,2);
    	
    	JPanel timePanel = new JPanel(timeLayout);
    	
    	countdownField.setEditable(false);
    	countdownField.setHorizontalAlignment(JTextField.CENTER);
    	countdownField.setFont(countdownFont);
    	countdownField.setText("00:00:00");
    	
    	timePanel.add(countdownLabel);
    	timePanel.add(countdownField);

    	elapsedField.setEditable(false);
    	elapsedField.setHorizontalAlignment(JTextField.CENTER);
    	elapsedField.setFont(elapsedFont);
    	elapsedField.setText("00:00:00");
    	
    	timePanel.add(elapsedLabel);
    	timePanel.add(elapsedField);

    	centralPanel.add(timePanel, "wrap");
    	
    	GridLayout buttonLayout = new GridLayout(1, 3);
    	
    	JPanel buttonPanel = new JPanel(buttonLayout);
    	startButton.addActionListener(this);
    	pauseButton.addActionListener(this);
    	stopButton.addActionListener(this);
    	buttonPanel.add(startButton);
    	buttonPanel.add(pauseButton, "");
    	buttonPanel.add(stopButton, "");
    	
    	centralPanel.add(buttonPanel, "spanx, growx, wrap");
    	
    	panel.add(centralPanel, "wrap");
    	
    	display = new JTextArea(100,150);
        display.setMargin(new Insets(5,5,5,5));
        display.setEditable(false);
        
        JScrollPane myPane = new JScrollPane(display, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        panel.add(myPane, "alignybottom, h 100:320, wrap");
        
        
        // Initial state of system
        paused = false;
        started = false;
        
        // Allowing interface to be displayed
    	setSize(400, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
       
    	
	}
	
	// TODO: These methods can be used in the action listeners above.
	public synchronized void writeDataFile(File f) throws IOException, FileNotFoundException {

	}
	
	// TODO: These methods can be used in the action listeners above.
	public synchronized String readDataFile(File f) throws IOException, ClassNotFoundException {
		
		String result = new String();
  
		return result;
	}

    public static void main(String[] args) {

        Timer timer = new Timer();

    }

    @Override
	public void actionPerformed(ActionEvent e) {
    	 // TODO: SAVE: This method should allow the user to specify a file name to which to save the contents of the text area using a 
        // JFileChooser. You should check to see that the file does not already exist in the system.
    	if(e.getSource() == saveData) {
    		if(stopped == true) { //Checks to make sure the timer has been stopped before allowing the user to save
        		int	returnVal = chooser.showSaveDialog(Timer.this);
    				if(returnVal== JFileChooser.APPROVE_OPTION) {
    					file= chooser.getSelectedFile();
    						 FileOutputStream out = null;
    						 ObjectOutputStream objectOut = null;

    						try{ 
    							out = new FileOutputStream(file);
    							objectOut = new ObjectOutputStream(out);
    							objectOut.writeObject(display.getText());
    						}
    						catch (IOException ex) {
    							ex.printStackTrace();
    						}
    							finally{
    							if(out!=null){try {
    								out.close();
    							} catch (IOException e1) {
    								// TODO Auto-generated catch block
    								e1.printStackTrace();
    							}}
    							if(objectOut!=null){try {
    								out.close();
    							} catch (IOException e1) {
    								// TODO Auto-generated catch block
    								e1.printStackTrace();
    							}}
    							}
    				}
    		} else {
    			JOptionPane.showMessageDialog(Timer.this, "Error: Timer must be stopped before saving.", "Error", JOptionPane.ERROR_MESSAGE);
    		}
    		
    	
    		  // TODO: DISPLAY DATa: This method should retrieve the contents of a file representing a previous report using a JFileChooser.
            // The result should be displayed as the contents of a dialog object.
    	
    	}else if (e.getSource() == displayData) {
			int returnVal= chooser.showOpenDialog(Timer.this);
			if(returnVal== JFileChooser.APPROVE_OPTION) {
					file= chooser.getSelectedFile();
				
					 FileInputStream in = null;
					 ObjectInputStream objectIn = null;

					try{ 
						
						in = new FileInputStream(file);
						objectIn = new ObjectInputStream(in);
						String data = (String)objectIn.readObject();
						//Creating the window to display the file contents
						JFrame frame = new JFrame();
			            frame.setSize(300,350);
			            frame.setLocationRelativeTo(null);
			            frame.setAlwaysOnTop(true);
			            frame.setLayout(new BorderLayout());
			            JTextArea textArea = new JTextArea();
			            frame.add(textArea, BorderLayout.CENTER);
			            frame.setVisible(true);
			            textArea.setText(data);
						display.setText(data);
							
						
					}
					catch (IOException ex) {
						ex.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
						finally{
						if(in!=null){try {
							in.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}}
						if(objectIn!=null){try {
							in.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}}
						}

				
			}
				
    		
    		// TODO: START: This method should check to see if the application is already running, and if not, launch a TimerThread object.
    		// If the application is running, you may wish to ask the user if the existing thread should be stopped and a new thread started.
            // It should begin by launching a TimerDialog to get the number of seconds to count down, and then pass that number of seconds along
    		// with the seconds since the start (0) to the TimerThread constructor.
    		// It can then display a message in the text area stating how long the countdown is for.	
    	} else if (e.getSource() == startButton) {
    		if(countdownField.getText().equals("00:00:00")) {
    			started = false; // if the timer has finished it is set back to being not started
    		}
    		if(started == false) { //Check to see if the timer is running
    			stopped = false;
    			tDialog = new TimerDialog(Timer.this, secondsToRun, true);
    			countdownThread = new TimerThread(countdownField, elapsedField, tDialog.getSeconds(), secondsSinceStart, Timer.this);
    			pauseThread = countdownThread;
    			thread = new Thread(countdownThread);
    			if(tDialog.getSeconds() != 0) { //If the user inputs 0 for hour, minute and second values then no message will be displayed when they start the timer
    				display.append("Countdown for " + tDialog.getSeconds() + " seconds.\n");
        			thread.start();
        			started = true;
    			}
    		} else { // if the timer is running show a message allowing the user to stop current timer and start a new one
    			 int reply = JOptionPane.showConfirmDialog(Timer.this, "Do you want to restart the timer?", "Warning", JOptionPane.YES_NO_CANCEL_OPTION);
    			 if (reply == JOptionPane.YES_OPTION) {
    				 stopButton.doClick();
    				 started = false;
    				 startButton.doClick();
    				 
    			 }
    		}
    		
    		
    		// TODO: PAUSE: This method should call the TimerThread object's pause method and display a message in the text area
            // indicating whether this represents pausing or restarting the timer.
    	} else if (e.getSource() == pauseButton) {

    		pauseThread.pause();
    		if(started == true) {
    			if (pauseButton.getText() == "PAUSE") {
        			pauseButton.setText("RESUME");
        			display.append("Paused at:        " +  pauseThread.getElapsedSeconds() + " seconds.\n");
        		} else {
        			pauseButton.setText("PAUSE");
        			display.append("Resumed at:    " +  pauseThread.getElapsedSeconds() + " seconds.\n");
        		}
    		}
    		
    		 // TODO: STOP: This method should stop the TimerThread object and use appropriate methods to display the stop time
            // and the total amount of time remaining in the countdown (if any).
    		
    	} else if (e.getSource() == stopButton) {
    		if(started == true) { //only activates the stop button if the timer was actually started
    			pauseThread.stop();
    			stopped = true;
        		started = false;
        		if(pauseThread.getCountdownSeconds() != 0) { //if the timer still had time left before finishing then a message is displayed
        			display.append("Stopped with " + pauseThread.getCountdownSeconds() + " seconds remaining\n");
        		}
        		
    		}
    		
    	}

	}
    
    //This message gets called by TimerThread class to display the "TIME UP" message when the timer has stopped
    public void stopMessage() {
    	JOptionPane.showMessageDialog(Timer.this, "TIME UP", "Message", JOptionPane.INFORMATION_MESSAGE);
    }

}

